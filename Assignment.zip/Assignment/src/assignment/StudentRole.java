package assignment;

public class StudentRole extends User {
    private String program;
    private String intake;
    private String supervisorID;

    public StudentRole(String userID, String name, String email, String password, String role, String program, String intake, String status, int failedLoginAttempts, String supervisorID) {
        super(userID, name, email, password, role, program, intake, status, failedLoginAttempts);
        this.program = program;
        this.intake = intake;
        this.supervisorID = supervisorID;
    }

    @Override
    public String getProgram() { return program; }
    public String getIntake() { return intake; }
    public String getSupervisorID() { return supervisorID; }
    
    @Override
    public void setProgram(String program) { this.program = program; }
    public void setIntake(String intake) { this.intake = intake; }
    public void setSupervisorID(String supervisorID) { this.supervisorID = supervisorID; }

    @Override
    public String toFileString() {
        return String.join(",",
            getUserID(), getName(), getEmail(), getPassword(), getRole(),
            program, intake, getStatus(), String.valueOf(getFailedLoginAttempts())
        );
    }
}
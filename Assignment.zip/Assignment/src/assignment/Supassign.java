package assignment;

public class Supassign {
    private String supervisorID;
    private String studentID;
    private String studentName;
    private String subject;

    public Supassign(String supervisorID, String studentID, String studentName, String subject) {
        this.supervisorID = supervisorID;
        this.studentID = studentID;
        this.studentName = studentName;
        this.subject = subject;
    }
    
    public String getSupervisorID() { return supervisorID; }
    public String getStudentID() { return studentID; }
    public String getStudentName() { return studentName; }
    public String getSubject() { return subject; }
    
    public void setSupervisorID(String supervisorID) { this.supervisorID = supervisorID; }
    public void setStudentID(String studentID) { this.studentID = studentID; }
    public void setStudentName(String studentName) { this.studentName = studentName; }
    public void setSubject(String subject) { this.subject = subject; }


    public static Supassign fromCsvLine(String line) {
        String[] parts = line.split(",", -1);
        if (parts.length < 4) return null;
        return new Supassign(parts[0], parts[1], parts[2], parts[3]);
    }
    
    @Override
    public String toString() {
        return supervisorID + "," + studentID + "," + studentName + "," + subject;
    }
}

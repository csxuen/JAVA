package assignment;

import java.io.*;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.ArrayList;

public class SupervisorDashboard extends javax.swing.JFrame {
    private DefaultTableModel tmodel = new DefaultTableModel(
    new Object[]{"Slot ID", "Slot Date", "Slot Time", "Slot Status"}, 0);
    private final String[] columnName ={"Student ID", "Student Name", "Slot ID","Date", "Time", "Status", "Approve","Reject"};
    private DefaultTableModel model = new DefaultTableModel();
    private DefaultTableModel amodel = new DefaultTableModel();
    
    private ArrayList<Supassign> assignList = new ArrayList<>();
    private ArrayList<Supslots> slotList = new ArrayList<>();
    private String supervisorID;
        
    public SupervisorDashboard(String userID) {
        this.supervisorID = userID;
        loggedInUserId = userID;

        initComponents(); 

        jTable1.setModel(assignedModel);
        jTable2.setModel(amodel);
        jTable3.setModel(tmodel);

        setSupervisorNameField(getSupervisorName(userID));
        jLabel1.setText("Supervisor Dashboard - " + getSupervisorNameField());
        jLabel2.setText("Welcome back, " + getSupervisorNameField() + "!");

        setupAssignedStudentsTable();
        setupPendingRequestsTable();
        setupAvailableSlotsTable();
        loadSlots();
        updateCounts();
        }
    
        private void saveAvailableSlotsToFile() {
        String filename = "C:\\Users\\Dell\\OneDrive - Asia Pacific University\\Object Oriented Programming\\Slot.txt";
        File file = new File(filename);

    java.util.List<String> allLines = new java.util.ArrayList<>();

    try {
        if (file.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = br.readLine()) != null) {
                    if (!line.trim().isEmpty() && !line.endsWith("," + loggedInUserId)) {
                        allLines.add(line);
                    }
                }
            }
        }

        for (int i = 0; i < tmodel.getRowCount(); i++) {
            Object idObj = tmodel.getValueAt(i, 0);
            Object dateObj = tmodel.getValueAt(i, 1);
            Object timeObj = tmodel.getValueAt(i, 2);
            Object statusObj = tmodel.getValueAt(i, 3);

            String slotID = idObj != null ? idObj.toString() : String.valueOf(i + 1);
            String slotDate = dateObj != null ? dateObj.toString() : "";
            String slotTime = timeObj != null ? timeObj.toString() : "";
            String slotStatus = statusObj != null ? statusObj.toString() : "";

            allLines.add(slotID + "," + slotDate + "," + slotTime + "," + slotStatus + "," + loggedInUserId);
        }

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(file))) {
            for (String line : allLines) {
                bw.write(line);
                bw.newLine();
            }
        }

        System.out.println("Slots for " + supervisorName + " saved successfully!");
        JOptionPane.showMessageDialog(this, "Slots saved successfully!");

    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error saving slots: " + e.getMessage());
        e.printStackTrace();
    }
    }
        
//table 2 
        private void setupPendingRequestsTable(){ 
            amodel.setColumnIdentifiers(columnName); 
            String filename = "C:\\Users\\Dell\\OneDrive - Asia Pacific University\\Object Oriented Programming\\Date.txt"; 
            String userfile = "C:\\Users\\Dell\\OneDrive - Asia Pacific University\\Object Oriented Programming\\user.txt";
            
            try { 
    FileReader fr = new FileReader(filename); 
    BufferedReader br = new BufferedReader(fr); 
    String line; 
    
    while ((line = br.readLine()) != null) { 
        String[] data = line.split(","); 
        
        if (data.length >= 7) { 
            String SupervisorID = data[0].trim(); 
            
            if (SupervisorID.equalsIgnoreCase(loggedInUserId)) { 
                
                String studentID = data[6].trim();
                String studentName = "";

                try (BufferedReader userReader = new BufferedReader(new FileReader(userfile))) {
                    String userLine;
                    while ((userLine = userReader.readLine()) != null) {
                        String[] userData = userLine.split(",");
                        if (userData.length >= 2) {
                            String userId = userData[0].trim();
                            if (userId.equalsIgnoreCase(studentID)) {
                                studentName = userData[1].trim(); // 拿到学生名字
                                break;
                            }
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

                System.out.println("Student name: " + studentName);

                amodel.addRow(new Object[]{studentID, studentName, data[2], data[3], data[4], data[5], "Approve", "Reject"});
                } 
                } 
                }    
                br.close(); 
                fr.close(); 

                } catch (IOException e) { 
                    e.printStackTrace();
                } 

                jTable2.setModel(amodel); 
                jTable2.getColumn("Approve").setCellRenderer(new ButtonRenderer()); 
                jTable2.getColumn("Approve").setCellEditor(new ButtonEditor(new JCheckBox(), "Approve")); 
                jTable2.getColumn("Reject").setCellRenderer(new ButtonRenderer()); 
                jTable2.getColumn("Reject").setCellEditor(new ButtonEditor(new JCheckBox(), "Reject")); 

                updateCounts();
       
                }
        
    
        
    private boolean isSlotAvailable(String requestedDate, String requestedTime) {
        DefaultTableModel availableModel = (DefaultTableModel) jTable3.getModel();

        for (int i = 0; i < availableModel.getRowCount(); i++) {
            String slotDate = availableModel.getValueAt(i, 1).toString().trim();  
            String slotTime = availableModel.getValueAt(i, 2).toString().trim();  
            String slotStatus = availableModel.getValueAt(i, 3).toString().trim(); 

            if (slotDate.equalsIgnoreCase(requestedDate)
                    && slotTime.equalsIgnoreCase(requestedTime)
                    && slotStatus.equalsIgnoreCase("Available")) {
                return true; 
            }
        }
        return false; 
    }
    
    private DefaultTableModel assignedModel = new DefaultTableModel();
    private DefaultTableModel pendingModel = new DefaultTableModel();
    private DefaultTableModel slotsModel = new DefaultTableModel();

    
    private String supervisorName;
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(SupervisorDashboard.class.getName());
    public static String loggedInUserId = null;
    private int manualPendingAdjustment = 0;
    
    private final java.util.List<String> feedbackList = new java.util.ArrayList<>();
    
    public String getSupervisorNameField(){
        return supervisorName;
    }
    
    public void setSupervisorNameField(String supervisorName) {
        this.supervisorName = supervisorName;
    }
    
    private void savePendingRequestsToFile() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("C:\\Users\\Dell\\OneDrive - Asia Pacific University\\Object Oriented Programming\\Date.txt"))) {
            for (int i = 0; i < amodel.getRowCount(); i++) {
                bw.write(
                    loggedInUserId + "," +                        // Supervisor ID
                    getSupervisorNameField() + "," +              // Supervisor Name
                    amodel.getValueAt(i, 2) + "," +               // Slot ID
                    amodel.getValueAt(i, 3) + "," +               // Date
                    amodel.getValueAt(i, 4) + "," +               // Time
                    amodel.getValueAt(i, 5) + "," +               // Status
                    amodel.getValueAt(i, 0)         // StudentID
                );
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel1.setText("Supervisor Dashboard");

        jLabel2.setText("Welcome back, Supervisor!");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Assigned Students");

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Pending Requests");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Available slots");

        jTable1.setModel(model);
        jScrollPane1.setViewportView(jTable1);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel6.setText("Assigned Students");

        jTable2.setModel(amodel);
        jScrollPane2.setViewportView(jTable2);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel7.setText("Pending Appointment Requests");

        jTable3.setModel(tmodel);
        jScrollPane3.setViewportView(jTable3);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel8.setText("Available Time Slots");

        jButton1.setText("Add Slot");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Logout");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("View Feedback");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Student Feedback");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setText("Announcement");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 666, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(201, 201, 201)
                                .addComponent(jButton1))
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 502, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton2))
                        .addGap(0, 28, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 765, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGap(12, 12, 12))))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 451, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(63, 63, 63))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jButton5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(25, 25, 25)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton3)
                                .addGap(18, 18, 18)
                                .addComponent(jButton4))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(jLabel7))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(jButton1))))
                .addGap(13, 13, 13)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 246, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(38, 38, 38)
                .addComponent(jButton2)
                .addContainerGap(83, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String slotDate = JOptionPane.showInputDialog(this, "Enter slot date (YYYY-MM-DD):");
        if (slotDate == null || slotDate.trim().isEmpty()) return;

        String slotTime = JOptionPane.showInputDialog(this, "Enter slot time (e.g., 10:00 AM):");
        if (slotTime == null || slotTime.trim().isEmpty()) return;
    
        int nextId = tmodel.getRowCount() + 1;
        String slotID = String.valueOf(nextId);

        tmodel.addRow(new Object[]{slotID, slotDate, slotTime, "Available"});

        saveAvailableSlotsToFile();
        updateCounts();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        this.dispose();
        new UserLogInPageGUI().setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        SupervisorFeedback dash = new SupervisorFeedback(supervisorID);
        dash.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        SupStudentFeedback sp = new SupStudentFeedback();
        sp.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        SPAnnouncement an = new SPAnnouncement();
        an.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton5ActionPerformed
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new SupervisorDashboard(loggedInUserId).setVisible(true));
    }
    
    private void setupAssignedStudentsTable(){
        assignedModel = new DefaultTableModel(
            new Object[]{"Intake Code", "Supervisor ID", "Supervisor Name", "Student ID", "Student Name", "Subject", "Feedback"},0);

        File assignFile = new File("C:\\Users\\Dell\\OneDrive - Asia Pacific University\\Object Oriented Programming\\Assign.txt");
        try (BufferedReader br = new BufferedReader(new FileReader(assignFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 6 && parts[1].equalsIgnoreCase(supervisorID)) {
                    assignedModel.addRow(parts);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading assigned students.");
        }

        jTable1.setModel(assignedModel);
        jTable1.getColumn("Feedback").setCellRenderer(new ButtonRenderer());
        jTable1.getColumn("Feedback").setCellEditor(new FeedbackButtonEditor(new JCheckBox()));
        updateCounts();
    }

    private void setupAvailableSlotsTable(){
        tmodel.setColumnIdentifiers(new Object[]{"Slot ID", "Slot Date", "Slot Time", "Slot Status"});
        jTable3.setModel(tmodel);

        String filename = "C:\\Users\\Dell\\OneDrive - Asia Pacific University\\Object Oriented Programming\\Slot.txt";
        File file = new File(filename);

        if (!file.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 5 && parts[4].equalsIgnoreCase(loggedInUserId)) {
                    tmodel.addRow(new Object[]{parts[0], parts[1], parts[2], parts[3]});
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading available slots for " + supervisorName);
            e.printStackTrace();
        }
    }
    
    private void saveFeedbackToFile(String intakeCode, String supervisorID, String supervisorName, String studentID, String studentName, String subject, String feedback) {
        File file = new File("C:\\Users\\Dell\\OneDrive - Asia Pacific University\\Object Oriented Programming\\SupervisorFeedback.txt");

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(file, true))) {
            bw.write(intakeCode + "," + supervisorID + "," + supervisorName + "," + studentID + "," + studentName + "," + subject + "," + feedback);
            bw.newLine();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving feedback: " + e.getMessage());
        }
    }

    private void writeTableData(BufferedWriter bw, DefaultTableModel model, String section) throws IOException {bw.write(section + ":\n");
        for (int i = 0; i < model.getRowCount(); i++) {
            StringBuilder sb = new StringBuilder();
            int colLimit = model.getColumnCount();

            if (section.equals("Assigned Students")) {
                colLimit = model.getColumnCount() - 1;
            } else if (section.equals("Pending Requests")) {
                colLimit = model.getColumnCount() - 2;
            }

            for (int j = 0; j < colLimit; j++) {
                Object value = model.getValueAt(i, j);
                sb.append(value != null ? value.toString() : "");
                if (j < colLimit - 1) sb.append(",");
            }
            bw.write(sb.toString());
            bw.newLine();
        }
        bw.newLine();
    }
    
    class ButtonRenderer extends JButton implements TableCellRenderer{
        public ButtonRenderer() { setOpaque(true);}
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column){
            
            setText((value == null) ? "" : value.toString());
            return this;
        }
    }
    
    class ButtonEditor extends DefaultCellEditor{
        private String label;
        private final JButton button;
        private boolean clicked;
        private int row;
        
        public ButtonEditor(JCheckBox checkBox, String actionType){
            super(checkBox);
            this.label = actionType;
            this.button = new JButton();
            button.setOpaque(true);
            button.addActionListener(e -> fireEditingStopped());
            this.label = actionType;
        }
        
        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column){
            this.row = row;
            button.setText(label);
            clicked = true;
            return button;
        }
        
        @Override
        public Object getCellEditorValue(){
            if(clicked){
                DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
                
                String studentId = model.getValueAt(row, 6).toString();
                String supervisorName  = model.getValueAt(row, 1).toString();
                String courseName = model.getValueAt(row, 2).toString();
                String date = model.getValueAt(row, 3).toString();
                String currentStatus = model.getValueAt(row, 4).toString();
                
                if (label.equals("Approve")) {
                    DefaultTableModel pendingModel = (DefaultTableModel) jTable2.getModel();
                    DefaultTableModel slotsModel = (DefaultTableModel) jTable3.getModel();

                    String time = pendingModel.getValueAt(row, 4).toString();

                    boolean slotFound = false;

                    for (int i = 0; i < slotsModel.getRowCount(); i++) {
                        String slotDate = slotsModel.getValueAt(i, 1).toString();
                        String slotTime = slotsModel.getValueAt(i, 2).toString();
                        String slotStatus = slotsModel.getValueAt(i, 3).toString();

                        if (slotDate.equals(date) && slotTime.equals(time) && slotStatus.equals("Available")) {
                            slotsModel.setValueAt("Booked", i, 3);
                            pendingModel.setValueAt("Approved", row, 5);
                            JOptionPane.showMessageDialog(button, "Request approved for " + studentId);
                            slotFound = true;
                            break; 
                        }
                    }

                    if (!slotFound) {
                        JOptionPane.showMessageDialog(button, "Please add a slot before approving this request.", "No Slot Found", JOptionPane.WARNING_MESSAGE);
                    }
                    savePendingRequestsToFile();
                    saveAvailableSlotsToFile();
                }else if(label.equals("Reject")){
                    model.setValueAt("Rejected", row, 5);
                    JOptionPane.showMessageDialog(button, "Request rejected for " + studentId);

                    String requestdate = model.getValueAt(row, 3).toString();
                    String requesttime = model.getValueAt(row, 4).toString();

                    DefaultTableModel assignedModel = (DefaultTableModel) jTable1.getModel();
                    for (int i = 0; i < assignedModel.getRowCount(); i++){
                        if (assignedModel.getValueAt(i, 3).equals(studentId)){
                            assignedModel.removeRow(i);
                            break;
                        }
                    }

                    DefaultTableModel slotsModel = (DefaultTableModel) jTable3.getModel();
                    for (int i = 0; i < slotsModel.getRowCount(); i++) {
                        String slotDate = slotsModel.getValueAt(i, 1).toString();
                        String slotTime = slotsModel.getValueAt(i, 2).toString();
                        String slotStatus = slotsModel.getValueAt(i, 3).toString();

                        if (slotDate.equals(requestdate) && slotTime.equals(requesttime) && slotStatus.equalsIgnoreCase("Booked")) {
                            slotsModel.setValueAt("Available", i, 3);
                            break;
                        }
                    }
                    savePendingRequestsToFile();
                    saveAvailableSlotsToFile();
                }
                updateCounts();
            }
            clicked = false;
            return label;
        }
    }
    
    class FeedbackButtonEditor extends DefaultCellEditor {
        private final JButton button;
        private boolean clicked;
        private int row;

        public FeedbackButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton("Give Feedback");
            button.setOpaque(true);
            button.addActionListener(e -> fireEditingStopped());
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            this.row = row;
            button.setText("Feedback");
            clicked = true;
            return button;
        }

        @Override
        public Object getCellEditorValue() {
            if (clicked) {
                DefaultTableModel model = (DefaultTableModel) jTable1.getModel();

                String intakeCode = model.getValueAt(row, 0).toString();
                String supervisorID = model.getValueAt(row, 1).toString();
                String supervisorName = model.getValueAt(row, 2).toString();
                String studentID = model.getValueAt(row, 3).toString();
                String studentName = model.getValueAt(row, 4).toString();
                String subject = model.getValueAt(row, 5).toString();

                String feedback = JOptionPane.showInputDialog(
                    null,
                    "Enter feedback for " + studentName + ":",
                    "Give Feedback",
                    JOptionPane.PLAIN_MESSAGE
                );

                if (feedback != null && !feedback.trim().isEmpty()) {
                    saveFeedbackToFile(intakeCode, supervisorID, supervisorName, 
                                       studentID, studentName, subject, feedback.trim());
                    JOptionPane.showMessageDialog(null, "Feedback saved for " + studentName);
                }
            }

            clicked = false;
            return button.getText();
        }
        
    }
    
    private void loadAssignedStudents() {
        assignList.clear();
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0);

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Dell\\OneDrive - Asia Pacific University\\Object Oriented Programming\\Assign.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                Supassign sa = Supassign.fromCsvLine(line);
                if (sa != null && sa.getSupervisorID().equals(supervisorID)) {
                    assignList.add(sa);
                    model.addRow(new Object[]{
                        sa.getStudentID(),
                        sa.getStudentName(),
                        sa.getSubject()
                    });
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading assigned students: " + e.getMessage());
        }
    }
    
    private void loadSlots() {
        tmodel.setRowCount(0); 
        String filename = "C:\\Users\\Dell\\OneDrive - Asia Pacific University\\Object Oriented Programming\\Slot.txt";

        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length >= 5) {
                    String slotID = data[0].trim();
                    String slotDate = data[1].trim();
                    String slotTime = data[2].trim();
                    String slotStatus = data[3].trim();
                    String supervisorId = data[4].trim();

                    if (supervisorId.equalsIgnoreCase(loggedInUserId)) {
                        tmodel.addRow(new Object[]{slotID, slotDate, slotTime, slotStatus});
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading available slots: " + e.getMessage());
        }
    }
    
    private void updateCounts(){
        jTextField1.setText(String.valueOf(jTable1.getRowCount()));
        jTextField2.setText(String.valueOf(countPendingRequests() + manualPendingAdjustment));
        jTextField3.setText(String.valueOf(countAvailableSlots()));
    }
    
    private int countPendingRequests(){
        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
        int count = 0;

        for (int i = 0; i < model.getRowCount(); i++) {
            Object status = model.getValueAt(i, 5); 
            if (status != null && status.toString().equalsIgnoreCase("Pending")) {
                count++;}
        }
        return count;
    }
    
    private int countAvailableSlots(){
        DefaultTableModel model = (DefaultTableModel) jTable3.getModel();
        int count = 0;
        for(int i = 0; i < model.getRowCount(); i++){
            Object status = model.getValueAt(i, 3);
            if (status != null && status.toString().equalsIgnoreCase("Available")){
                count++;
            }
        }
        return count;
    }
    
        private String getSupervisorName(String userID){
            File userFile = new File("C:\\Users\\Dell\\OneDrive - Asia Pacific University\\Object Oriented Programming\\user.txt");
            try (BufferedReader br = new BufferedReader(new FileReader(userFile))){
                String line;
                while ((line = br.readLine()) != null){
                    String[] parts = line.split(",");
                    if (parts[0].equalsIgnoreCase(userID)) {
                        return parts[1]; 
                    }
                }
            } catch (IOException e){
                JOptionPane.showMessageDialog(this, "Error reading supervisor name.");
            }
            setSupervisorNameField("Unknown Supervisor");
            return getSupervisorNameField();
    }
        
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    // End of variables declaration//GEN-END:variables
}

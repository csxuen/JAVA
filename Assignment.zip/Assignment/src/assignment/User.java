package assignment;

public class User {
    private String userID;
    private String name;
    private String email;
    private String password;
    private String role;
    private String program;
    private String intakeCode;
    private String status;
    private int failedLoginAttempts;

    public User(String userID, String name, String email, String password, String role, String program, String intakeCode, String status, int failedLoginAttempts) {
        this.userID = userID;
        this.name = name;
        this.email = email;
        this.password = password;
        this.role = role;
        this.program = program;
        this.intakeCode = intakeCode;
        this.status = status;
        this.failedLoginAttempts = failedLoginAttempts;
    }

    public String getUserID() { return userID; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPassword() { return this.password; }
    public String getRole() { return role; }
    public String getProgram() { return program; }
    public String getIntakeCode() { return intakeCode; }
    public String getStatus() { return status; }
    public int getFailedLoginAttempts() { return failedLoginAttempts; }
    
    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }
    public void setPassword(String password) { this.password = password; }
    public void setRole(String role) { this.role = role; }
    public void setProgram(String program) { this.program = program; }
    public void setIntakeCode(String intakeCode) { this.intakeCode = intakeCode; }
    public void setStatus(String status) { this.status = status; }
    public void setFailedLoginAttempts(int attempts) { this.failedLoginAttempts = attempts; }

    public void incrementFailedLoginAttempts() { this.failedLoginAttempts++; }
    public void resetFailedLoginAttempts() { this.failedLoginAttempts = 0; }
    
    public boolean verifyPassword(String inputPassword) {
        return this.password.equals(inputPassword);
    }
    
    public String toFileString() {
        return String.join(",",
            userID, name, email, password, role, program, intakeCode, status, String.valueOf(failedLoginAttempts)
        );
    }
    
    public static User fromString(String line) {
        String[] parts = line.split(",");
        if (parts.length >= 9) {
            return new User(
                parts[0].trim(), parts[1].trim(), parts[2].trim(), 
                parts[3].trim(), parts[4].trim(), parts[5].trim(), parts[6].trim(), parts[7].trim(), Integer.parseInt(parts[8].trim())
            );
        }
        return null;
    }
    
    @Override
    public String toString() {
        return String.format("%s - %s (%s) - %s", role, name, userID, status);
    }
}

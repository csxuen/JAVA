package assignment;

public class SupervisorClass {
    private String supervisorID;
    private String studentID;
    private String studentName;
    private String subject;
    private String feedbackText;

    public SupervisorClass(String supervisorID, String studentID, String studentName, String subject, String feedbackText) {
        this.supervisorID = supervisorID;
        this.studentID = studentID;
        this.studentName = studentName;
        this.subject = subject;
        this.feedbackText = feedbackText;
    }

    public String getSupervisorID() { return supervisorID; }
    public String getStudentID() { return studentID; }
    public String getStudentName() { return studentName; }
    public String getSubject() { return subject; }
    public String getFeedbackText() { return feedbackText; }

    public static SupervisorClass fromCsvLine(String line) {
        String[] parts = line.split(",", -1); 
        if (parts.length >= 7) {
            return null;
        }
            String supervisorID = parts[1];
            String studentID = parts[3];
            String studentName = parts[4];
            String subject = parts[5];
            String feedbackText = parts[6];
            return new SupervisorClass(supervisorID, studentID, studentName, subject, feedbackText);
        }
        
    @Override
    public String toString() {
        return supervisorID + "," + studentID + "," + studentName + "," + subject + "," + feedbackText;
    }
}
    



package assignment;

public class GeneralUser extends User {
    
    public GeneralUser(String userID, String name, String email, String password, String role, String program, String intakeCode, String status, int failedLoginAttempts) {
        super(userID, name, email, password, role, program, intakeCode, status, failedLoginAttempts);
    }

    @Override
    public String toFileString() {
        return String.join(",",
            getUserID(), getName(), getEmail(), getPassword(), getRole(),
            getProgram(), getIntakeCode(), getStatus(), String.valueOf(getFailedLoginAttempts())
        );
    }
}

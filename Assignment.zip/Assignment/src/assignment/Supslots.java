package assignment;

public class Supslots {
    private String supervisorID; 
    private String date;
    private String time;
    private String status; 
    private String slotID; 

    public Supslots(String slotID, String date, String time, String status, String supervisorID) {
        this.slotID = slotID;
        this.date = date;
        this.time = time;
        this.status = status;
        this.supervisorID = supervisorID;
    }
    
    public String getSupervisorID() { return supervisorID; }
    public String getDate() { return date; }
    public String getTime() { return time; }
    public String getStatus() { return status; }
    public String getSlotID() { return slotID; }

    public static Supslots fromCsvLine(String line) {
        String[] parts = line.split(",", -1);
        if (parts.length < 5) return null;
        return new Supslots(parts[0].trim(), parts[1].trim(), parts[2].trim(), parts[3].trim(), parts[4].trim());
    }
    
    @Override
    public String toString() {
        return slotID + "," + date + "," + time + "," + status + "," + supervisorID;
    }
}

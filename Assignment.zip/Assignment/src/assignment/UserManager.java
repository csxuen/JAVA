package assignment;

import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;

public class UserManager {
    private List<User> users;  
    private static final String USER_FILE_PATH = "C:\\Users\\Dell\\OneDrive - Asia Pacific University\\Object Oriented Programming\\user.txt";
    private static final String failedLoginFile = "C:\\Users\\Dell\\OneDrive - Asia Pacific University\\Object Oriented Programming\\failedlogindata.txt";
    
    public UserManager() {
        this.users = new ArrayList<>();
        loadUsersFromFile();
    }
    
    private void loadUsersFromFile() {
        users.clear();
        File userFile = new File(USER_FILE_PATH);
        
        if (!userFile.exists()) {
            System.out.println("User file not found: " + USER_FILE_PATH);
            return;
        }
        
        try (BufferedReader br = new BufferedReader(new FileReader(userFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                User user = User.fromString(line);  
                if (user != null) {
                    users.add(user);
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading users: " + e.getMessage());
        }
    }
    
    public List<User> getAllUsers() {
        return new ArrayList<>(users);
    }
    
    public boolean createUser(String userID, String name, String email, String password, String role, String program, String intakeCode) {
        for (User user : users) {
            if (user.getUserID().equalsIgnoreCase(userID)) {
                return false;
            }
        }
        
        User newUser = new User(userID, name, email, password, role, program, intakeCode, "Active", 0);
        users.add(newUser);
        saveUsersToFile();
        return true;
    }
    
    public boolean updateUser(String userID, String name, String email, String role, String program, String intakeCode, String status) {
        for (User user : users) {
            if (user.getUserID().equalsIgnoreCase(userID)) {
                user.setName(name);
                user.setEmail(email);
                user.setRole(role);
                user.setProgram(program);
                user.setIntakeCode(intakeCode);
                user.setStatus(status);
                saveUsersToFile();
                return true;
            }
        }
        return false;
    }
    
    public boolean deleteUser(String userID) {
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getUserID().equalsIgnoreCase(userID)) {
                users.remove(i);
                saveUsersToFile();
                return true;
            }
        }
        return false;
    }
    
    public List<User> getUsersWithFailedAttempts() {
        List<User> result = new ArrayList<>();
        for (User user : users) {
            if (user.getFailedLoginAttempts() > 0) {
                result.add(user);
            }
        }
        return result;
    }
    
    public List<User> getLockedUsers() {
        List<User> result = new ArrayList<>();
        for (User user : users) {
            if (user.getStatus().equalsIgnoreCase("Locked") || user.getFailedLoginAttempts() >= 3) {
                result.add(user);
            }
        }
        return result;
    }
    
    public int resetUserPassword(String userID, String oldPassword, String newPassword) {
        User user = getUserByID(userID);
        if (user == null) {
            return 1;
        }
        
        if (!user.getPassword().equals(oldPassword)) {
            return 2;
        }
        
        if (user.getPassword().equals(newPassword)) {
            return 3;
        }
        
        user.setPassword(newPassword);
        saveUsersToFile();
        return 0;
    }
    
    public void unlockUser(String userID) {
        for (User user : users) {
            if (user.getUserID().equals(userID)) {
                user.setStatus("Active");
                user.resetFailedLoginAttempts();
                saveUsersToFile();
                break;
            }
        }
    }
    
    private void saveUsersToFile() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(USER_FILE_PATH))) {
            for (User user : users) {
                bw.write(user.toFileString());
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving users: " + e.getMessage());
        }
    }
    
    public User authenticate(String userID, String password) {
        for (User user : users) {
            if (user.getUserID().equals(userID) && 
                user.verifyPassword(password) && 
                !user.getStatus().equalsIgnoreCase("Locked")) {
                
                user.resetFailedLoginAttempts();
                saveUsersToFile();
                return user;
            }
        }
        return null;
    }
 
    public String getLastFailedAttemptTime(String userID) {
        try {
            File file = new File(failedLoginFile);
            if (!file.exists()) {
                return null;
            }
            
            List<String> lines = java.nio.file.Files.readAllLines(file.toPath());
            for (int i = lines.size() - 1; i >= 0; i--) {
                String line = lines.get(i);
                if (line.startsWith(userID + ",")) {
                    return line.split(",")[1]; 
                }
            }
        } catch (IOException e) {
        }
        return null;
    }
    
    public void handleFailedLogin(String userID) {
        for (User user : users) {
            if (user.getUserID().equals(userID)) {
                user.incrementFailedLoginAttempts();
                
                try (FileWriter fw = new FileWriter(failedLoginFile, true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {
                
                    String timestamp = java.time.LocalDateTime.now().format(
                    java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
                    out.println(userID + "," + timestamp);
                
                    } catch (IOException e) {
                        System.err.println("Error writing to failed login file: " + e.getMessage());
                }
                
                if (user.getFailedLoginAttempts() >= 3) {
                    user.setStatus("Locked");
                }
                
                saveUsersToFile();
                break;
            }
        }
    }
    
    public User getUserByID(String userID) {
        for (User user : users) {
            if (user.getUserID().equals(userID)) {
                return user;
            }
        }
        return null;
    }
}
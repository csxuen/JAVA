package assignment;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;

import java.io.*;

public class Appoinment extends javax.swing.JFrame {
    DefaultComboBoxModel lcombo = new DefaultComboBoxModel();
    DefaultComboBoxModel acombo = new DefaultComboBoxModel();
    private final String[] columnName = {"supervisorID","supervisor","Number","Date","Time","Status"};
    private final DefaultTableModel model = new DefaultTableModel();
    private int row = -1;
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Appoinment.class.getName());
    public static String loggedInUserId;
    
    public Appoinment() {
        initComponents();
        model.setColumnIdentifiers(columnName);
        loadDataFromFile();
    }

    private void loadDataFromFile(){
    try {
        model.setRowCount(0);
        lcombo.removeAllElements();
        acombo.removeAllElements();
        
        lcombo.addElement("");
        
        File file = new File("C:\\Users\\Dell\\OneDrive - Asia Pacific University\\Object Oriented Programming\\Date.txt");
        if (file.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] data = line.split(",");
                    if (data.length >= 7) {
                        String studentID = data[6].trim();
                        if (studentID.equalsIgnoreCase(loggedInUserId)) {
                            model.addRow(new Object[]{
                                data[0], // supervisorID
                                data[1], // supervisorName
                                data[2], //number
                                data[3], // Date
                                data[4], // Time
                                data[5]// Status
                            });
                        }
                    }
                }
            }
        } 

        File assignFile = new File("C:\\Users\\Dell\\OneDrive - Asia Pacific University\\Object Oriented Programming\\assign.txt");
        if (!assignFile.exists()) {
            JOptionPane.showMessageDialog(this, "assign.txt not found!");
            return;
        }

        try (BufferedReader br2 = new BufferedReader(new FileReader(assignFile))) {
            String line;
            while ((line = br2.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 4) {
                    String supervisorID = parts[1].trim();
                    String supervisorName = parts[2].trim();
                    String studentID = parts[3].trim();

                    if (studentID.equalsIgnoreCase(loggedInUserId)) {
                        lcombo.addElement(supervisorID + " | " + supervisorName);
                    }
                }
            }
        }

        if (lcombo.getSize() == 0) {
            lcombo.addElement("No assigned supervisor");
        }

        supervisor.addActionListener(e -> loadAvailableSlots());

    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error reading files: " + e.getMessage());
        e.printStackTrace();
    }
}
    
    private void loadAvailableSlots() {
    acombo.removeAllElements();

    Object selected = supervisor.getSelectedItem();
    if (selected == null || selected.toString().startsWith("No")) {
        acombo.addElement("No assigned supervisor");
        return;
    }

    String[] parts = selected.toString().split("\\|");
    String supervisorID = parts[0].trim();

    boolean isAssigned = false;
    File assignFile = new File("C:\\Users\\Dell\\OneDrive - Asia Pacific University\\Object Oriented Programming\\Assign.txt");
    if (!assignFile.exists()) {
        acombo.addElement("Assign.txt not found");
        return;
    }

    try (BufferedReader brAssign = new BufferedReader(new FileReader(assignFile))) {
        String line;
        while ((line = brAssign.readLine()) != null) {
            String[] data = line.split(",");
            if (data.length >= 4) {
                String assignSupervisorID = data[1].trim();
                String assignStudentID = data[3].trim();

                if (assignSupervisorID.equalsIgnoreCase(supervisorID)
                        && assignStudentID.equalsIgnoreCase(loggedInUserId)) {
                    isAssigned = true;
                    break;
                }
            }
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error reading assign.txt: " + e.getMessage());
        return;
    }

    if (!isAssigned) {
        acombo.addElement("");
        return;
    }

    File slotFile = new File("C:\\Users\\Dell\\OneDrive - Asia Pacific University\\Object Oriented Programming\\Slot.txt");
    if (!slotFile.exists()) {
        acombo.addElement("Slot.txt not found");
        return;
    }

    boolean foundSlot = false;
    try (BufferedReader brSlot = new BufferedReader(new FileReader(slotFile))) {
        String line;
        while ((line = brSlot.readLine()) != null) {
            String[] parts2 = line.split(",");
            if (parts2.length >= 5) {
                String slotNumber = parts2[0].trim();
                String date = parts2[1].trim();
                String time = parts2[2].trim();
                String status = parts2[3].trim();
                String slotSupervisorID = parts2[4].trim();

                if (slotSupervisorID.equalsIgnoreCase(supervisorID)
                        && status.equalsIgnoreCase("Available")) {
                    acombo.addElement(slotNumber + " | " + date + " | " + time);
                    foundSlot = true;
                }
            }
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error reading Slot.txt: " + e.getMessage());
        return;
    }

    if (!foundSlot) {
        acombo.addElement("No available slots for this supervisor");
    }
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        supervisor = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jComboBox2 = new javax.swing.JComboBox<>();
        jLabel15 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("Manage appoinments");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 185, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        jButton2.setText("return");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        supervisor.setModel(lcombo);
        supervisor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                supervisorActionPerformed(evt);
            }
        });

        jTable1.setModel(model);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jTable1MouseReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jComboBox2.setModel(acombo);
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel15.setText("Anvailable Time Slot");

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel17.setText("Lecturer:");

        jButton1.setText("Make Appointment");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton4.setText("Delete Appointment");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel13)
                .addGap(117, 117, 117)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 541, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel2)
                        .addGap(164, 164, 164))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton2)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel17)
                                                .addGap(18, 18, 18)
                                                .addComponent(supervisor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(jLabel15, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jComboBox2, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGap(21, 21, 21))
                                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 512, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel17)
                            .addComponent(supervisor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(86, 86, 86)
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton4)
                        .addGap(183, 183, 183)
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton2)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        MainPage sp = new MainPage();
        sp.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void supervisorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_supervisorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_supervisorActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String Supervisor = supervisor.getSelectedItem().toString();
        String Timedslot = jComboBox2.getSelectedItem().toString();
        String Pending = "Pending";
        
        String newRowData[] = {Supervisor,Timedslot,Pending};
        
        model.addRow(newRowData);
        
        String[] lectureParts = Supervisor.split("\\|");
        String LectureID = lectureParts[0].trim();
        String LectureName = lectureParts.length > 1 ? lectureParts[1].trim() : "";
        
        String[] TimeSlotParts = Timedslot.split("\\|");
        String number = TimeSlotParts[0].trim();
        String Date = TimeSlotParts.length > 2 ? TimeSlotParts[1].trim() : "";
        String Time = TimeSlotParts.length > 2 ? TimeSlotParts[2].trim() : "";
   
        try {
        FileWriter fw = new FileWriter("C:\\Users\\Dell\\OneDrive - Asia Pacific University\\Object Oriented Programming\\Date.txt", true);
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(LectureID + "," +LectureName +  "," + number +","+ Date + ","+Time+","+Pending+ "," +loggedInUserId);
        bw.newLine();

        
        bw.close();
        fw.close();
        
        model.setRowCount(0); // Clear current table
        loadDataFromFile();   // Reload from file
        JOptionPane.showMessageDialog(this, "Appointment added and saved successfully!");
        
        }catch(IOException e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saving data: " + e.getMessage()); 
            
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTable1MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseReleased
        row = jTable1.getSelectedRow();
        if (row < 0) return;
        
        String SupervisorID = String.valueOf(model.getValueAt(row, 0));
        String Supervisor = String.valueOf(model.getValueAt(row, 1));
        String Date = String.valueOf(model.getValueAt(row, 2));
        String TIme = String.valueOf(model.getValueAt(row, 3));

        
        supervisor.setSelectedItem(SupervisorID + " | " + Supervisor);
        jComboBox2.setSelectedItem(Date + " | " +TIme);
    }//GEN-LAST:event_jTable1MouseReleased

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
         if (row == -1) {
        JOptionPane.showMessageDialog(this, "Please select a row to delete!");
        return;
    }

    int opt = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete?");
    if (opt == 0) {
        String SupervisorID = String.valueOf(model.getValueAt(row, 0));
        String Supervisor = String.valueOf(model.getValueAt(row, 1));
        String Number = String.valueOf(model.getValueAt(row, 2));
        String Date = String.valueOf(model.getValueAt(row, 3));
        String Time = String.valueOf(model.getValueAt(row, 4));
        String Status = String.valueOf(model.getValueAt(row, 5));
        String StudentID = loggedInUserId;

        model.removeRow(row);
        row = -1;

        try {
            File file = new File("C:\\Users\\Dell\\OneDrive - Asia Pacific University\\Object Oriented Programming\\Date.txt");
            BufferedReader br = new BufferedReader(new FileReader(file));
            StringBuilder sb = new StringBuilder();
            String eachLine;

            String targetLine = SupervisorID + "," + Supervisor + "," + Number + "," + Date + "," + Time + "," + Status + "," + StudentID;

            while ((eachLine = br.readLine()) != null) {
                if (!eachLine.trim().equalsIgnoreCase(targetLine.trim())) {
                    sb.append(eachLine).append("\n");
                }
            }
            br.close();

            BufferedWriter bw = new BufferedWriter(new FileWriter(file, false));
            bw.write(sb.toString());
            bw.close();

            JOptionPane.showMessageDialog(this, "Appointment deleted successfully!");

            model.setRowCount(0);
            loadDataFromFile();

        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error deleting record: " + e.getMessage());
        }
    }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Appoinment().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JComboBox<String> supervisor;
    // End of variables declaration//GEN-END:variables
}
